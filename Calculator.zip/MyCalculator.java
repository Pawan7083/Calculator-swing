import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Calc extends JFrame implements ActionListener{
    JLabel label=new JLabel();
    JTextField text=new JTextField();
    JRadioButton onRadioButton= new JRadioButton("On");
    JRadioButton offRadioButton= new JRadioButton("Off");
    JButton buttonClear=new JButton("C");
    JButton buttonDelete=new JButton("Dlt");
    JButton buttonDiv=new JButton("/");
    JButton buttonSqrt=new JButton("sqrt");
    JButton buttonSqare=new JButton("x^2");
    JButton buttonReverse=new JButton("1/X");
    JButton buttonMult=new JButton("*");
    JButton buttonSeven=new JButton("7");
    JButton buttonEight=new JButton("8");
    JButton buttonNine=new JButton("9");
    JButton buttonSub=new JButton("-");
    JButton buttonFour=new JButton("4");
    JButton buttonFive=new JButton("5");
    JButton buttonSix=new JButton("6");
    JButton buttonAdd=new JButton("+");
    JButton buttonOne=new JButton("1");
    JButton buttonTwo=new JButton("2");
    JButton buttonThree=new JButton("3");
    JButton buttonEqual=new JButton("=");
    JButton buttonplusminus=new JButton("+/-");
    JButton buttonZero=new JButton("0");
    JButton buttonDot=new JButton(".");
    Double num=0.0,num1=0.0;int container=0;

    Calc(){
        this.setBounds(100,50,300,500);
        this.getContentPane().setBackground(Color.black);
        sizeDefine();
        addComponent();
    }
    public void sizeDefine(){
        setTitle("Calculator");
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100,30,310,500);
        getContentPane().setBackground(Color.black);
        getContentPane().setLayout(null);
    }

    public void addComponent(){
    
    Font font=new Font("Arial",Font.BOLD,20);

    label.setBounds(10,0,270,40);
    label.setText("");
    label.setFont(font);
    label.setBackground(Color.black);
    label.setForeground(Color.white);
    label.setHorizontalAlignment(SwingConstants.RIGHT);
    this.add(label);

    text.setBounds(10,40,270,40);
    text.setFont(font);
    text.setBackground(Color.white);
    text.setForeground(Color.black);
    text.setHorizontalAlignment(SwingConstants.RIGHT);
    this.add(text);
    
    onRadioButton.setText("on");
    onRadioButton.setBounds(10,100,50,20);
    //onRadioButton.setFont(font);
    onRadioButton.setForeground(Color.white); 
    onRadioButton.setBackground(Color.black); 
    this.add(onRadioButton);
    onRadioButton.setEnabled(false);
    onRadioButton.addActionListener(this);

    offRadioButton.setText("off");
    offRadioButton.setBounds(10,120,50,20);
    //offRadioButton.setFont(font);
    offRadioButton.setBackground(Color.black);
    offRadioButton.setForeground(Color.white);
    this.add(offRadioButton);
    offRadioButton.addActionListener(this);

    ButtonGroup btnGroup=new ButtonGroup();
    btnGroup.add(onRadioButton);
    btnGroup.add(offRadioButton);

    buttonClear.setBounds(80,100,60,40);
    buttonClear.setFont(font);
    buttonClear.setBackground(Color.red);
    buttonClear.setForeground(Color.green);
    this.add(buttonClear);
    buttonClear.addActionListener(this);

    buttonDelete.setBounds(150,100,60,40);
    buttonDelete.setFont(font);
    buttonDelete.setBackground(Color.red);
    buttonDelete.setForeground(Color.green);
    this.add(buttonDelete);
    buttonDelete.addActionListener(this);

    buttonDiv.setBounds(220,100,60,40);
    buttonDiv.setFont(font);
    buttonDiv.setBackground(Color.yellow);
    buttonDiv.setForeground(Color.black);
    this.add(buttonDiv);
    buttonDiv.addActionListener(this);

    buttonSqare.setBounds(10,160,60,40);
    buttonSqare.setFont(font);
    buttonSqare.setBackground(Color.white);
    buttonSqare.setForeground(Color.black);
    this.add(buttonSqare);
    buttonSqare.addActionListener(this);

    buttonSqrt.setBounds(80,160,60,40);
    buttonSqrt.setFont(font);
    buttonSqrt.setBackground(Color.white);
    buttonSqrt.setForeground(Color.black);
    this.add(buttonSqrt);
    buttonSqrt.addActionListener(this);

    buttonReverse.setBounds(150,160,60,40);
    buttonReverse.setFont(font);
    buttonReverse.setBackground(Color.white);
    buttonReverse.setForeground(Color.black);
    this.add(buttonReverse);
    buttonReverse.addActionListener(this);

    buttonMult.setBounds(220,160,60,40);
    buttonMult.setFont(font);
    buttonMult.setBackground(Color.yellow);
    buttonMult.setForeground(Color.black);
    this.add(buttonMult);
    buttonMult.addActionListener(this);

    buttonSeven.setBounds(10,220,60,40);
    buttonSeven.setFont(font);
    buttonSeven.setBackground(Color.white);
    buttonSeven.setForeground(Color.black);
    this.add(buttonSeven);
    buttonSeven.addActionListener(this);

    buttonEight.setBounds(80,220,60,40);
    buttonEight.setFont(font);
    buttonEight.setBackground(Color.white);
    buttonEight.setForeground(Color.black);
    this.add(buttonEight);
    buttonEight.addActionListener(this);

    buttonNine.setBounds(150,220,60,40);
    buttonNine.setFont(font);
    buttonNine.setBackground(Color.white);
    buttonNine.setForeground(Color.black);
    this.add(buttonNine);
    buttonNine.addActionListener(this);

    buttonSub.setBounds(220,220,60,40);
    buttonSub.setFont(font);
    buttonSub.setBackground(Color.yellow);
    buttonSub.setForeground(Color.black);
    this.add(buttonSub);
    buttonSub.addActionListener(this);

    buttonFour.setBounds(10,280,60,40);
    buttonFour.setFont(font);
    buttonFour.setBackground(Color.white);
    buttonFour.setForeground(Color.black);
    this.add(buttonFour);
    buttonFour.addActionListener(this);

    buttonFive.setBounds(80,280,60,40);
    buttonFive.setFont(font);
    buttonFive.setBackground(Color.white);
    buttonFive.setForeground(Color.black);
    this.add(buttonFive);
    buttonFive.addActionListener(this);

    buttonSix.setBounds(150,280,60,40);
    buttonSix.setFont(font);
    buttonSix.setBackground(Color.white);
    buttonSix.setForeground(Color.black);
    this.add(buttonSix);
    buttonSix.addActionListener(this);

    buttonAdd.setBounds(220,280,60,40);
    buttonAdd.setFont(font);
    buttonAdd.setBackground(Color.yellow);
    buttonAdd.setForeground(Color.black);
    this.add(buttonAdd);
    buttonAdd.addActionListener(this);

    buttonOne.setBounds(10,340,60,40);
    buttonOne.setFont(font);
    buttonOne.setBackground(Color.white);
    buttonOne.setForeground(Color.black);
    this.add(buttonOne);
    buttonOne.addActionListener(this);

    buttonTwo.setBounds(80,340,60,40);
    buttonTwo.setFont(font);
    buttonTwo.setBackground(Color.white);
    buttonTwo.setForeground(Color.black);
    this.add(buttonTwo);
    buttonTwo.addActionListener(this);

    buttonThree.setBounds(150,340,60,40);
    buttonThree.setFont(font);
    buttonThree.setBackground(Color.white);
    buttonThree.setForeground(Color.black);
    this.add(buttonThree);
    buttonThree.addActionListener(this);

    buttonEqual.setBounds(220,340,60,100);
    buttonEqual.setFont(font);
    buttonEqual.setBackground(Color.yellow);
    buttonEqual.setForeground(Color.black);
    this.add(buttonEqual);
    buttonEqual.addActionListener(this);

    buttonZero.setBounds(10,400,130,40);
    buttonZero.setFont(font);
    buttonZero.setBackground(Color.white);
    buttonZero.setForeground(Color.black);
    this.add(buttonZero);
    buttonZero.addActionListener(this);

    buttonDot.setBounds(150,400,60,40);
    buttonDot.setFont(font);
    buttonDot.setBackground(Color.white);
    buttonDot.setForeground(Color.black);
    this.add(buttonDot);
    buttonDot.addActionListener(this);   
    }

    public void enabled(){
        text.setEnabled(true);
        offRadioButton.setEnabled(true);
        onRadioButton.setEnabled(false);
        buttonOne.setEnabled(true);
        buttonTwo.setEnabled(true);
        buttonThree.setEnabled(true);
        buttonFour.setEnabled(true);
        buttonFive.setEnabled(true);
        buttonSix.setEnabled(true);
        buttonSeven.setEnabled(true);
        buttonEight.setEnabled(true);
        buttonNine.setEnabled(true);
        buttonEqual.setEnabled(true);
        buttonZero.setEnabled(true);
        buttonDot.setEnabled(true);
        buttonAdd.setEnabled(true);
        buttonSub.setEnabled(true);
        buttonMult.setEnabled(true);
        buttonDiv.setEnabled(true);
        buttonSqare.setEnabled(true);
        buttonSqrt.setEnabled(true);
        buttonReverse.setEnabled(true);
        buttonClear.setEnabled(true);
        buttonDelete.setEnabled(true);
    }
    public void disabled(){
        text.setEnabled(false);
        text.setText("");
        label.setText("");
        offRadioButton.setEnabled(false);
        onRadioButton.setEnabled(true);
        buttonOne.setEnabled(false);
        buttonTwo.setEnabled(false);
        buttonThree.setEnabled(false);
        buttonFour.setEnabled(false);
        buttonFive.setEnabled(false);
        buttonSix.setEnabled(false);
        buttonSeven.setEnabled(false);
        buttonEight.setEnabled(false);
        buttonNine.setEnabled(false);
        buttonEqual.setEnabled(false);
        buttonZero.setEnabled(false);
        buttonDot.setEnabled(false);
        buttonAdd.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonMult.setEnabled(false);
        buttonDiv.setEnabled(false);
        buttonSqare.setEnabled(false);
        buttonSqrt.setEnabled(false);
        buttonReverse.setEnabled(false);
        buttonClear.setEnabled(false);
        buttonDelete.setEnabled(false);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==onRadioButton){
            enabled();
        }
        else if(e.getSource()==offRadioButton){
            disabled();
        }
        else if(e.getSource()==buttonClear){
            label.setText("");
            text.setText("");
            num=0.0;num1=0.0;container=0;
        }
        else if(e.getSource()==buttonDelete){
            StringBuilder back=new StringBuilder(text.getText());
            int length=text.getText().length();
            if(length>0){
                back.deleteCharAt(length-1);
                text.setText(back.toString());
            }
            else return;
        }
        else if(e.getSource()==buttonZero){
            if(text.getText().equals("0"))return;
            else text.setText(text.getText()+ "0");
        }
        else if(e.getSource()==buttonDot){
            if(text.getText().contains(".")) return ;
            else text.setText(text.getText()+".");
        }
        else if(e.getSource()==buttonOne){
            text.setText(text.getText()+"1");
        }
        else if(e.getSource()==buttonTwo){
            text.setText(text.getText()+"2");
        }
        else if(e.getSource()==buttonThree){
            text.setText(text.getText()+"3");
        }
        else if(e.getSource()==buttonFour){
            text.setText(text.getText()+"4");
        }
        else if(e.getSource()==buttonFive){
            text.setText(text.getText()+"5");
        }
        else if(e.getSource()==buttonSix){
            text.setText(text.getText()+"6");
        }
        else if(e.getSource()==buttonSeven){
            text.setText(text.getText()+"7");
        }
        else if(e.getSource()==buttonEight){
            text.setText(text.getText()+"8");
        }
        else if(e.getSource()==buttonNine){
            text.setText(text.getText()+"9");
        }
        else if(e.getSource()==buttonAdd){
            if(text.getText().isEmpty()) return;
            else{
                num=Double.parseDouble(text.getText());
                label.setText(text.getText()+" +");
                text.setText("");
                container=1;
           }
            
        }
        else if(e.getSource()==buttonSub){
            if(text.getText().isEmpty()) return;
            num=Double.parseDouble(text.getText());
            label.setText(text.getText()+" -");
            text.setText("");
            container=2;
        }
        else if(e.getSource()==buttonMult){
            if(text.getText().isEmpty()) return;
            num=Double.parseDouble(text.getText());
            label.setText(text.getText()+" *");
            text.setText("");
            container=3;
        }
        else if(e.getSource()==buttonDiv){
            if(text.getText().isEmpty()) return;
            num=Double.parseDouble(text.getText());
            label.setText(text.getText()+" /");
            text.setText("");
            container=4;
        }
        else if(e.getSource()==buttonEqual){
            Double sum =0.0;
            if(container==0) return ;
            // else{
                num1=Double.parseDouble(text.getText());
                label.setText(label.getText()+" "+text.getText());
                switch(container){
                    
                    case 1:
                        sum=num+num1;
                        num1=0.0;
                        break;
                    case 2:
                        sum=num-num1;
                        num1=0.0;
                        break;
                    case 3:
                        sum=num*num1;
                        num1=0.0;
                        break;
                    case 4:
                        sum=num/num1;
                        num1=0.0;
                        break;
                }
                
                text.setText(Double.toString(sum));
                arithmetic(num,num1,container);
            //}

        }
        
    }
    void arithmetic(Double num,Double num1,int container){
       
    }
}

public class MyCalculator {
    public static void main(String p[]){
        Calc calc=new Calc();
    }
}
